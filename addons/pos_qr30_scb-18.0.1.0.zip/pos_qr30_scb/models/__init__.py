from . import pos_bank
from . import res_partner_bank
from . import pos_payment_method
from . import pos_payment
