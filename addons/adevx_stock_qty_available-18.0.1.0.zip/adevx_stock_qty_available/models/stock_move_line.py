from odoo import api, models
from odoo.exceptions import UserError


class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    @api.onchange('quantity')
    def _onchange_quantity_check_on_hand(self):
        if self.move_id and any([self.move_id.location_usage, self.move_id.location_dest_usage]) == 'internal':
            if self.quantity > self.move_id.on_hand:
                raise UserError('Quantity must be less than or equal to %s' % self.move_id.on_hand)
