from odoo import api, fields, models


class StockMove(models.Model):
    _inherit = 'stock.move'

    on_hand = fields.Float(string='On-Hand', compute="_compute_on_hand", store=True)

    @api.depends('product_id', 'location_id', 'location_dest_id', 'picking_id.state')
    def _compute_on_hand(self):
        for rec in self:
            rec.on_hand = 0
            if rec.picking_id:
                if rec.location_usage == 'internal':
                    quant_ids = self.env['stock.quant'].search([
                        ('product_id', '=', rec.product_id.id), ('location_id', 'child_of', rec.location_id.id)])
                    rec.on_hand = sum(quant_ids.mapped('quantity'))
                elif rec.location_dest_usage == "internal":
                    quant_ids = self.env['stock.quant'].search([
                        ('product_id', '=', rec.product_id.id), ('location_id', 'child_of', rec.location_dest_id.id)])
                    rec.on_hand = sum(quant_ids.mapped('quantity'))
