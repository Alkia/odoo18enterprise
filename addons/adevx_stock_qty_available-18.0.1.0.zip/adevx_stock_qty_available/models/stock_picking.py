from odoo import models
from odoo.exceptions import UserError


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        for rec in self:
            validate = False

            if rec.picking_type_id.code == 'outgoing':
                if not self.env.company.allow_negative_on_hand:
                    validate = True
                else:
                    for line in rec.move_ids_without_package:
                        line.quantity = line.product_uom_qty

            elif rec.picking_type_id.code == 'internal' and rec.location_id.usage == 'internal':
                if not self.env.company.allow_negative_on_hand:
                    validate = True

            if validate:
                for line in rec.move_ids_without_package:
                    if line.product_id.type == 'consu' and line.product_id.is_storable:
                        if line.product_uom_qty > line.on_hand:
                            raise UserError('Please Check On-Hand Quantity !!')
        return super().button_validate()
