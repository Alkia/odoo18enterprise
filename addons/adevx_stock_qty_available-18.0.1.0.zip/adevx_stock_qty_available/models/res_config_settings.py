from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    allow_negative_on_hand = fields.Boolean(
        related="company_id.allow_negative_on_hand", readonly=False)
