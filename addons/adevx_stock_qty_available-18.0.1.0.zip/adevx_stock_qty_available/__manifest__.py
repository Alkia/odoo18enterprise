{
    'name': 'Stock Qty Available',

    'summary': 'Qty Available In Stock Picking',
    'description': 'Qty Available In and Stock Picking',

    'author': 'Adevx',
    'category': 'Warehouse',
    "license": "OPL-1",
    'website': 'https://adevx.com',

    'depends': ['stock'],
    'data': [
        # views
        'views/stock_picking.xml',
        'views/res_config_settings.xml',
    ],

    'images': ['static/description/banner.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
}
