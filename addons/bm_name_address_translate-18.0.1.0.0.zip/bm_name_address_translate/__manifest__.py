# -*- coding: utf-8 -*-
# See LICENSE file for full licensing details.
# See COPYRIGHT file for full copyright details.
# Developed by Bizmate - Unbox Solutions Co., Ltd.

{
    'name': 'Name and Address Management for multiple language',
    'version': '18.0.1.0.0',
    'license': 'LGPL-3',
    'author': 'Bizmate',
    'category': 'Technical',
    'website': 'https://www.unboxsol.com',
    'live_test_url': 'https://bizmate18.unboxsol.com',
    'summary': "Allow name and address to be translated for multiple language (company, partner, user, employee, country state, resource, warehouse)",
    'price': 0,
    'currency': 'USD',
    'support': 'bizmate@unboxsol.com',

    'depends': [
        'base',
        'web',
        'hr',
        'stock'
    ],
    'data': [
        
    ],
    'auto_install': False,
    'images': ['static/description/images/banner.gif'],
}
