# -*- coding: utf-8 -*-
# See LICENSE file for full licensing details.
# See COPYRIGHT file for full copyright details.
# Developed by Bizmate - Unbox Solutions Co., Ltd.

from . import hr_employee_public
from . import hr_employee
from . import res_company
from . import res_country_state
from . import res_partner
from . import res_users
from . import resource_resource
from . import stock_warehouse